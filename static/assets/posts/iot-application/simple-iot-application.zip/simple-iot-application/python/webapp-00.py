# -*- coding: utf-8 -*-

import bottle

# initializing bottle app
app = bottle.Bottle()

# triggered when / is accessed from browser
# only accepts GET → no POST allowed
@app.route("/", method=["GET"])
def route_default():
	return "howdy from python"

# starting server on http://0.0.0.0:5000
if __name__ == "__main__":
	bottle.run(
		app = app,
		host = "0.0.0.0",
		port = 5000,
		debug = True,
		reloader = True,
		catchall = True,
	)
