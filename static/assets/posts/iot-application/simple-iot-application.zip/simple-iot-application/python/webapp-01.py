# -*- coding: utf-8 -*-

import time
import bottle
import random
import dataset

# initializing bottle app
app = bottle.Bottle()

# connects to sqlite database
# check_same_thread=False allows using it in multi-threaded mode
app.config["db"] = dataset.connect("sqlite:///data.db?check_same_thread=False")

# api key that will be used in Arduino code
app.config["api_key"] = "JtF2aUE5SGHfVJBCG5SH"

# triggered when /api is accessed from browser
# only accepts POST → no GET allowed
@app.route("/api", method=["POST"])
def route_default():
	status = 400
	ts = int(time.time()) # current timestamp
	value = bottle.request.body.read() # data from device
	api_key = bottle.request.get_header("api_key") # api key from header

	# outputs to console received data for debug reason
	print ">>> {} :: {}".format(value, api_key)

	# if api_key is correct and value is present
	# then writes attribute to point table
	if api_key == app.config["api_key"] and value:
		app.config["db"]["point"].insert(dict(ts=ts, value=value))
		status = 200

	# we only need to return status
	return bottle.HTTPResponse(status=status, body="")

# starting server on http://0.0.0.0:5000
if __name__ == "__main__":
	bottle.run(
		app = app,
		host = "0.0.0.0",
		port = 5000,
		debug = True,
		reloader = True,
		catchall = True,
	)
