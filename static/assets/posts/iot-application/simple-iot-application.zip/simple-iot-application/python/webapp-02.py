# -*- coding: utf-8 -*-

import time
import bottle
import json
import datetime
import random
import dataset

# initializing bottle app
app = bottle.Bottle()

# adds root directory as template folder
bottle.TEMPLATE_PATH.insert(0, "./")

# connects to sqlite database
# check_same_thread=False allows using it in multi-threaded mode
app.config["db"] = dataset.connect("sqlite:///data.db?check_same_thread=False")

# api key that will be used in Arduino code
app.config["api_key"] = "JtF2aUE5SGHfVJBCG5SH"

# triggered when / is accessed from browser
# only accepts GET → no POST allowed
@app.route("/", method=["GET"])
def route_default():
	return bottle.template("frontend.html")

# triggered when /api is accessed from browser
# accepts POST and GET
@app.route("/api", method=["GET", "POST"])
def route_default():

	# if method is POST then we write datapoint
	if bottle.request.method == "POST":
		status = 400
		ts = int(time.time()) # current timestamp
		value = bottle.request.body.read() # data from device
		api_key = bottle.request.get_header("Api-Key") # api key from header

		# outputs to console recieved data for debug reason
		print ">>> {} :: {}".format(value, api_key)

		# if api_key is correct and value is present
		# then writes attribute to point table
		if api_key == app.config["api_key"] and value:
			app.config["db"]["point"].insert(dict(ts=ts, value=value))
			status = 200

			# we only need to return status
			return bottle.HTTPResponse(status=status, body="")

	# if method is GET then we read datapoint
	else:
		response = []
		datapoints = app.config["db"]["point"].all()

		for point in datapoints:
			response.append({
				"date": datetime.datetime.fromtimestamp(int(point["ts"])).strftime("%Y-%m-%d %H:%M:%S"),
				"value": point["value"]
			})

		bottle.response.content_type = "application/json"
		return json.dumps(response)

# starting server on http://0.0.0.0:5000
if __name__ == "__main__":
	bottle.run(
		app = app,
		host = "0.0.0.0",
		port = 5000,
		debug = True,
		reloader = True,
		catchall = True,
	)
