const express = require('express');
const bodyParser = require('body-parser');
const SSETopic = require('sse-pubsub');

const app = express();
const port = process.env.PORT || 4000;

// topics container
const sseTopics = {};

app.use(bodyParser.json());

// open for all cors
app.all('*', (req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type');
  next();
});

// preflight request error fix
app.options('*', async (req, res) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type');
  res.send('OK');
});

// serve the event streams
app.get('/stream/:topic', async (req, res, next) => {
  const topic = req.params.topic;

  if (!(topic in sseTopics)) {
    sseTopics[topic] = new SSETopic({
      pingInterval: 0,
      maxStreamDuration: 15000,
    });
  }

  // subscribing client to topic
  sseTopics[topic].subscribe(req, res);
});

// accepts new messages into topic
app.post('/publish', async (req, res) => {
  let body = req.body;
  let status = 200;

  console.log('Incoming message:', req.body);

  if (
    body.hasOwnProperty('topic') &&
    body.hasOwnProperty('event') &&
    body.hasOwnProperty('message')
  ) {
    const topic = req.body.topic;
    const event = req.body.event;
    const message = req.body.message;

    if (topic in sseTopics) {
      // sends message to all the subscribers
      sseTopics[topic].publish(message, event);
    }
  } else {
    status = 400;
  }

  res.status(status).send({
    status,
  });
});

// returns JSON object of all opened topics
app.get('/status', async (req, res) => {
  res.send(sseTopics);
});

// health-check endpoint
app.get('/', async (req, res) => {
  res.send('OK');
});

// return a 404 if no routes match
app.use((req, res, next) => {
  res.set('Cache-Control', 'private, no-store');
  res.status(404).end('Not found');
});

// starts the server
app.listen(port, () => {
  console.log(`PubSub server running on http://localhost:${port}`);
});
