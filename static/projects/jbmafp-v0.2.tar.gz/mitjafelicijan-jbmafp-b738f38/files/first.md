---
title: "My first post"
url: first.html
date: 2023-06-29T14:51:39+02:00
type: post
draft: false
---

This is my first post. It ain't much but it's an honest post.

```lua
for k, v in pairs(arr) do
  print(k, v[1], v[2], v[3])
end
```
