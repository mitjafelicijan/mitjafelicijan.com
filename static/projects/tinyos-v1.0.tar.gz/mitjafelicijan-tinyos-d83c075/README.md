# TinyOS

TinyOS is a minimal, 32-bit x86 operating system implemented to get familiar
with OS development internals. I made this for fun and exploration.

## Specs

- **Architecture:** x86 (i386)
- **Bootloader:** 16-bit real-mode (NASM) -> 32-bit protected-mode.
- **Kernel:** Freestanding C (GCC).
- **Video:** VGA Mode 13h (320x200, 256 colors).
- **Interrupts:** IDT for hardware IRQs and CPU exceptions.
- **Input:** PS/2 keyboard.
- **Shell:** Basic CLI.

## Implementation Details

- `boot.asm`: 16-bit real-mode bootloader.
- `entry.asm`: Protected-mode initialization and kernel entry.
- `kmain.c`: Main kernel loop.
- `idt.c`: IDT configuration and interrupt routing.
- `keyboard.c`: PS/2 scancode to ASCII mapping.
- `shell.c`: Basic CLI.
- `link.ld`: Memory layout definition.

## Dependencies

- `nasm`
- `gcc` (i386 target support)
- `binutils` (ld with elf_i386 support)
- `qemu-system-x86_64`
- `make`

## Usage

Build:
```bash
make
```

Run:
```bash
make run
```

Clean:
```bash
make clean
```

## Memory Map

The kernel is loaded into memory starting at `0x1000`. The VGA buffer for Mode
13h is located at `0xA0000`.
