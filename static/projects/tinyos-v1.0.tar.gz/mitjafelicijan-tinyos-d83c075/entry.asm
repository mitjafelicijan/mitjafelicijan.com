; Kernel Entry Point
; This is a small assembly wrapper that ensures the C kernel is started correctly.
; Since C compilers don't guarantee the order of functions in the binary,
; this stub is linked at the very beginning of the kernel image.

[bits 32]        ; We are in 32-bit Protected Mode at this point
global _start
[extern kmain]   ; Inform the assembler that 'kmain' is defined elsewhere (in kmain.c)

_start:
	call kmain   ; Transfer control to the main function of our C kernel
	jmp $        ; If the kernel returns, halt the CPU in an infinite loop
