#include "idt.h"
#include "io.h"

struct idt_entry idt[256] __attribute__((aligned(16)));
struct idt_ptr idtp;

// Function defined in interrupts.asm
extern void load_idt(uint32_t idt_ptr);

void set_idt_gate(int n, uint32_t handler) {
	idt[n].base_low = handler & 0xFFFF;
	idt[n].selector = 0x08; // This matches CODE_SEG offset in GDT
	idt[n].zero = 0;
	idt[n].flags = 0x8E;    // Present, Ring 0, Interrupt Gate
	idt[n].base_high = (handler >> 16) & 0xFFFF;
}

void remap_pic() {
	// ICW1
	outb(0x20, 0x11);
	outb(0xA0, 0x11);

	// ICW2 (Offsets)
	outb(0x21, 0x20); // Master PIC starts at 0x20
	outb(0xA1, 0x28); // Slave PIC starts at 0x28

	// ICW3 (Cascade)
	outb(0x21, 0x04);
	outb(0xA1, 0x02);

	// ICW4 (8086 mode)
	outb(0x21, 0x01);
	outb(0xA1, 0x01);

	// Unmask only Keyboard (IRQ 1)
	outb(0x21, 0xFD);
	outb(0xA1, 0xFF);
}

extern void exception_handler_stub();

void init_idt() {
	// Zero out the IDT
	for (int i = 0; i < 256; i++) {
		idt[i].base_low = 0;
		idt[i].selector = 0x08;
		idt[i].zero = 0;
		idt[i].flags = 0x8E;
		idt[i].base_high = 0;
		set_idt_gate(i, (uint32_t)exception_handler_stub);
	}

	idtp.limit = (sizeof(struct idt_entry) * 256) - 1;
	idtp.base = (uint32_t)&idt;

	remap_pic();
	load_idt((uint32_t)&idtp);
}
