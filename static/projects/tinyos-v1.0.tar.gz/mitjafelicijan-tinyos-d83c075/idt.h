#ifndef IDT_H
#define IDT_H

#include <stdint.h>

// IDT Entry structure
struct idt_entry {
	uint16_t base_low;    // Lower 16 bits of handler address
	uint16_t selector;    // Kernel segment selector (CODE_SEG)
	uint8_t  zero;        // Always zero
	uint8_t  flags;       // Flags (Type/Attributes)
	uint16_t base_high;   // Upper 16 bits of handler address
} __attribute__((packed));

// IDT Pointer structure for LIDT
struct idt_ptr {
	uint16_t limit;
	uint32_t base;
} __attribute__((packed));

void init_idt();
void set_idt_gate(int n, uint32_t handler);

#endif
