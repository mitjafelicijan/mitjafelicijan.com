[bits 32]

global load_idt
load_idt:
	mov eax, [esp + 4]
	lidt [eax]
	ret

global enable_interrupts
enable_interrupts:
	sti
	ret

; ISR for Keyboard (IRQ 1 mapped to 0x21)
global keyboard_handler_stub
extern keyboard_handler

keyboard_handler_stub:
	pushad     ; Save all registers
	call keyboard_handler
	popad      ; Restore all registers
	iretd      ; Interrupt return (32-bit)

; Generic handler for unhandled interrupts/exceptions
global exception_handler_stub
extern exception_handler

exception_handler_stub:
	pushad
	call exception_handler
	popad
	iretd
