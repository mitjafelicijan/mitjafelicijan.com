#ifndef IO_H
#define IO_H

// Read a byte from a port
static inline unsigned char inb(unsigned short port) {
	unsigned char result;
	__asm__ volatile("inb %1, %0" : "=a"(result) : "Nd"(port));
	return result;
}

// Write a byte to a port
static inline void outb(unsigned short port, unsigned char data) {
	__asm__ volatile("outb %0, %1" : : "a"(data), "Nd"(port));
}

// Small delay for PIC operations
static inline void io_wait(void) {
	outb(0x80, 0);
}

#endif
