#include "screen.h"
#include "idt.h"
#include "keyboard.h"
#include "shell.h"
#include "font.h"

void draw_pixel(int x, int y, unsigned char color) {
	unsigned char* vga = (unsigned char*) 0xA0000;
	vga[y * 320 + x] = color;
}

void draw_char(int x, int y, char c, unsigned char color) {
	if (c < 0 || (unsigned char)c > 127) return;

	for (int i = 0; i < 8; i++) {
		unsigned char row = font8x8_basic[(unsigned char)c][i];
		for (int j = 0; j < 8; j++) {
			if ((row >> j) & 1) {
				draw_pixel(x + j, y + i, color);
			}
		}
	}
}

void draw_string(int x, int y, char* str, unsigned char color) {
	int i = 0;
	while (str[i] != 0) {
		draw_char(x + (i * 8), y, str[i], color);
		i++;
	}
}

void exception_handler() {
	draw_string(0, 0, "EXCEPTION OCCURRED!", 12); // Red text
	while(1);
}

void kmain() {
	// Initialize Interrupts
	init_idt();

	// Initialize Drivers
	init_keyboard();

	// Start Shell
	init_shell();

	// Enable Interrupts
	extern void enable_interrupts();
	enable_interrupts();

	// Loop forever
	while(1) {
		// Busy wait instead of hlt to avoid power management issues in some VMs
		// and to simplify debugging
		__asm__ volatile("pause");
	}
}
