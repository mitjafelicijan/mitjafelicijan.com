#ifndef SCREEN_H
#define SCREEN_H

void draw_pixel(int x, int y, unsigned char color);
void draw_char(int x, int y, char c, unsigned char color);
void draw_string(int x, int y, char* str, unsigned char color);

#endif
