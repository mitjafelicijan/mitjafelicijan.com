#include "shell.h"

// Forward declarations of drawing functions from kmain.c (or better, make a header)
extern void draw_string(int x, int y, char* str, unsigned char color);
extern void draw_char(int x, int y, char c, unsigned char color);
extern void draw_pixel(int x, int y, unsigned char color);

#define MAX_BUFFER 64
char command_buffer[MAX_BUFFER];
int buffer_index = 0;

int cursor_x = 10;
int cursor_y = 10;

void clear_screen_area() {
	// Clear the shell area (for simplicity, we'll just draw a black rectangle)
	for (int y = 0; y < 200; y++) {
		for (int x = 0; x < 320; x++) {
			draw_pixel(x, y, 0);
		}
	}
	cursor_x = 10;
	cursor_y = 10;
}

void print_prompt() {
	draw_string(cursor_x, cursor_y, "> ", 14); // Yellow prompt
	cursor_x += 16;
}

void init_shell() {
	clear_screen_area();
	print_prompt();
}

void execute_command() {
	command_buffer[buffer_index] = 0;
	cursor_x = 10;
	cursor_y += 12;

	if (buffer_index == 0) {
		// Empty command
	} else if (command_buffer[0] == 'c' && command_buffer[1] == 'l' && command_buffer[2] == 's') {
		clear_screen_area();
	} else if (command_buffer[0] == 'i' && command_buffer[1] == 'n' && command_buffer[2] == 'f' && command_buffer[3] == 'o') {
		for (int y = 0; y < 200; y++) {
			for (int x = 0; x < 320; x++) {
				draw_pixel(x, y, (unsigned char)(x + y));
			}
		}
		draw_string(100, 80, "Hello World!", 15);
		draw_string(80, 100, "TinyOS VGA Mode 13h", 14);
		draw_string(110, 120, "256 Colors", 10);
		cursor_x = 10;
		cursor_y = 140; // Move cursor below the text
	} else if (command_buffer[0] == 'h' && command_buffer[1] == 'e' && command_buffer[2] == 'l' && command_buffer[3] == 'p') {
		draw_string(cursor_x, cursor_y, "Commands: help, cls, info", 11);
		cursor_y += 12;
	} else {
		draw_string(cursor_x, cursor_y, "Unknown command", 12);
		cursor_y += 12;
	}

	buffer_index = 0;
	print_prompt();

	// Simple scrolling check
	if (cursor_y > 180) {
		clear_screen_area();
		print_prompt();
	}
}

void shell_handle_char(char c) {
	if (c == '\n') {
		execute_command();
	} else if (c == '\b') {
		if (buffer_index > 0) {
			buffer_index--;
			cursor_x -= 8;
			// Manually clear the character area with black pixels
			for (int i = 0; i < 8; i++) {
				for (int j = 0; j < 8; j++) {
					draw_pixel(cursor_x + j, cursor_y + i, 0);
				}
			}
		}
	} else if (buffer_index < MAX_BUFFER - 1) {
		command_buffer[buffer_index++] = c;
		draw_char(cursor_x, cursor_y, c, 15); // White text
		cursor_x += 8;
	}

	// Wrap check
	if (cursor_x > 300) {
		cursor_x = 10;
		cursor_y += 12;
	}
}
