#ifndef VERSION_H_
#define VERSION_H_

#define VERSION  "0.1"
#define WEBSITE  "https://github.com/mitjafelicijan/ttdaw"
#define LICENSE  "This is free software: you are free to change and redistribute it."
#define WARRANTY "There is NO WARRANTY, to the extent permitted by law."
#define AUTHOR   "Written by Mitja Felicijan <https://mitjafelicijan.com>."

#endif // VERSION_H_

